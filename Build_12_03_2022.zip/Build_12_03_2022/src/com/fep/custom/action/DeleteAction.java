package com.fep.custom.action;

import java.util.Locale;

import com.ibm.ecm.extension.PluginAction;
import com.ibm.json.java.JSONObject;

public class DeleteAction extends PluginAction {

	
	public String getId() {
		return "DeleteAction";
	}

	
	public String getName(Locale locale) {
		return "Delete";
	}

	
	public String getIcon() {
		return "SamplePluginAction.gif";
	}
	
	
	public String getIconClass() {
		return "";
	}

	
	public String getPrivilege() {
		return "";
	}

	public boolean isMultiDoc() {
		return true;
	}

	public boolean isGlobal() {
		return false;
	}

	public String getActionFunction() {
		return "fepUtilityPluginDeleteAction";
	}

	public String getServerTypes() {
		return "p8";
	}

	public String[] getMenuTypes() {
		return new String[0];
	}

	public JSONObject getAdditionalConfiguration(Locale locale) {
		return new JSONObject();
	}

	
	public String getActionModelClass() {
		return "fEPUtilityPluginDojo/DeleteAction";
	}
}
