package com.fep.custom.action;

import java.util.Locale;

import com.ibm.ecm.extension.PluginAction;
import com.ibm.json.java.JSONObject;

public class ComboChangeAction extends PluginAction {

	
	public String getId() {
		return "ComboChangeAction";
	}

	
	public String getName(Locale locale) {
		return "Combo";
	}

	
	public String getIcon() {
		return "SamplePluginAction.gif";
	}
	
	
	public String getIconClass() {
		return "";
	}

	
	public String getPrivilege() {
		return "";
	}

	public boolean isMultiDoc() {
		return true;
	}

	public boolean isGlobal() {
		return false;
	}

	public String getActionFunction() {
		return "fepUtilityPluginComboChangeAction";
	}

	public String getServerTypes() {
		return "p8";
	}

	public String[] getMenuTypes() {
		return new String[0];
	}

	public JSONObject getAdditionalConfiguration(Locale locale) {
		return new JSONObject();
	}

	
	public String getActionModelClass() {
		return "fEPUtilityPluginDojo/ComboChangeAction";
	}
}
