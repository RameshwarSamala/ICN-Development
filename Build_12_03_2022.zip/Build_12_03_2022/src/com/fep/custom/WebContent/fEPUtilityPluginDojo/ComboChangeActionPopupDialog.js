
define([
		"dojo/_base/declare",
		"dijit/form/Select",
		"ecm/widget/dialog/BaseDialog",
		"dojo/text!./templates/ComboChangeActionPopupDialog.html"
	],
	function(declare, Select, BaseDialog, template) {

	/**
	 * @name fEPUtilityPluginDojo.ComboChangeActionPopupDialog
	 * @class Provides a dialog whose main content is an html page displayed in an iframe.  
	 * @augments ecm.widget.dialog.BaseDialog
	 */
	return declare("fEPUtilityPluginDojo.ComboChangeActionPopupDialog", [ BaseDialog ], {
	/** @lends fEPUtilityPluginDojo.ComboChangeActionPopupDialog.prototype */	

		contentString: template,
		widgetsInTemplate: true,
		constructor:function (args) {
            if (args) {
                this._callback = args.callback;
            }
        },
		postCreate: function() {
			this.inherited(arguments);
			this.setResizable(true);
			this.setMaximized(true);
			//this.setWidth(550);
			this.setTitle("Combo Change");
			this.saveButton = this.addButton("Update", "_onUpdate", false, true);
		},
		
		_onUpdate:function () {
			console.log("on update")
            if (this._callback) {
                this._callback({name:"Test", isPublic:"YesCorrect"});
            }
            this.onCancel();
        }, 
        
        onCancel:function () {
        },
        
		show: function() {
			this.inherited("show", []);
		}
	});
});
