
define([
		"dojo/_base/declare",
		"dijit/form/Textarea",
		"ecm/widget/dialog/BaseDialog",
		"dojo/text!./templates/RecDateActionPopupDialog.html"
	],
	function(declare, Textarea, BaseDialog, template) {

	/**
	 * @name fEPUtilityPluginDojo.RecDateActionPopupDialog
	 * @class Provides a dialog whose main content is an html page displayed in an iframe.  
	 * @augments ecm.widget.dialog.BaseDialog
	 */
	return declare("fEPUtilityPluginDojo.RecDateActionPopupDialog", [ BaseDialog ], {
	/** @lends fEPUtilityPluginDojo.RecDateActionPopupDialog.prototype */	

		contentString: template,
		widgetsInTemplate: true,
		constructor:function (args) {
            if (args) {
                this._callback = args.callback;
            }
        },
		postCreate: function() {
			this.inherited(arguments);
			this.setResizable(false);
			this.setMaximized(false);
			this.setWidth(550);
			this.setTitle("Change Receipt Date");
			this.saveButton = this.addButton("Update", "_onUpdate", false, true);
		},
		
		_onUpdate:function () {
			console.log("on update")
            if (this._callback) {
                this._callback({name:"Test", isPublic:"YesCorrect"});
            }
            this.onCancel();
        }, 
        
        onCancel:function () {
        },
        
		show: function() {
			this.inherited("show", []);
		}
	});
});
