

define(["dojo/_base/lang",
	"fEPUtilityPluginDojo/AnnotationPopupDialog"
	], function(lang,AnnotationPopupDialog) {
	/**
	 * The cell decorator will make any value that contains an @ sign become an email link.
	 */
	
	lang.setObject("fepUtilityPluginAnnotationDecorator", function(data, rowId, rowIndex) {
		var _blankGif = require.toUrl("ecm/widget/resources/images/page_actualsize_23.png");
		var altName = "Annotation";
		var titleVal = "Annotation";
		if (data && data != "null") {
			var htmlStr = "<img class=\"ecmStatusIcon\" alt=\"" + altName + "\"" +
					" title=\"" + titleVal + "\" src=\"" + _blankGif + "\" />";
			//console.log(htmlStr);
			return htmlStr;
		} else {
			return "";
		}
		
	});
});
