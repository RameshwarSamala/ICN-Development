
define([
		"dojo/_base/declare",
		"dijit/form/Select",
		"ecm/widget/dialog/BaseDialog",
		"dojo/text!./templates/DocStatActionPopupDialog.html"
	],
	function(declare, Select, BaseDialog, template) {

	/**
	 * @name fEPUtilityPluginDojo.DocStatActionPopupDialog
	 * @class Provides a dialog whose main content is an html page displayed in an iframe.  
	 * @augments ecm.widget.dialog.BaseDialog
	 */
	return declare("fEPUtilityPluginDojo.DocStatActionPopupDialog", [ BaseDialog ], {
	/** @lends fEPUtilityPluginDojo.DocStatActionPopupDialog.prototype */	

		contentString: template,
		widgetsInTemplate: true,
		constructor:function (args) {
            if (args) {
                this._callback = args.callback;
            }
        },
		postCreate: function() {
			this.inherited(arguments);
			this.setResizable(true);
			this.setMaximized(false);
			this.setWidth(550);
			this.setTitle("frmFEPMaint");
			this.saveButton = this.addButton("Update", "_onUpdate", false, true);
		},
		
		_onUpdate:function () {
			console.log("on update")
            if (this._callback) {
                this._callback({name:"Test", isPublic:"YesCorrect"});
            }
            this.onCancel();
        }, 
        
        onCancel:function () {
        },
        
		show: function() {
			this.inherited("show", []);
		}
	});
});
