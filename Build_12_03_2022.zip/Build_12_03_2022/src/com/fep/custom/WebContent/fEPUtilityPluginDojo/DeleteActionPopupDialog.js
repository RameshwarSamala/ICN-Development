define([
		"dojo/_base/declare",
		"ecm/widget/dialog/BaseDialog",
		"dojo/text!./templates/DeleteActionPopupDialog.html"
	],
	function(declare, BaseDialog, template) {

	/**
	 * @name fEPUtilityPluginDojo.DeleteActionPopupDialog
	 * @class Provides a dialog whose main content is an html page displayed in an iframe.  
	 * @augments ecm.widget.dialog.BaseDialog
	 */
	return declare("fEPUtilityPluginDojo.DeleteActionPopupDialog", [ BaseDialog ], {
	/** @lends fEPUtilityPluginDojo.DeleteActionPopupDialog.prototype */	

		contentString: template,
		widgetsInTemplate: true,
		
		postCreate: function() {
			this.inherited(arguments);
			this.setResizable(true);
			this.setMaximized(false);
			this.setWidth(550);
			this.setTitle("Delete Documents from Imaging");
			this.saveButton = this.addButton("Yes", "_onYes", false, true);
		},
		
		_onYes:function () {
			console.log("on Yes")
            if (this._callback) {
                this._callback({name:"Test", isPublic:"YesCorrect"});
            }
            this.onCancel();
        }, 
        
        onCancel:function () {
        },
		
		show: function() {
			this.inherited("show", []);
		}
	});
});
