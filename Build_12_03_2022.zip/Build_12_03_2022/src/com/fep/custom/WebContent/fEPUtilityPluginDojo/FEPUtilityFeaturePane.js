/*
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2010, 2019
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/dom-attr",
	"dojo/dom",
	"dojo/dom-style",
	"dijit/registry",
	"dojo/dom-construct",
	"dojo/_base/array",
	"dijit/focus",
	"dijit/Dialog",
	"idx/layout/BorderContainer",
	"dijit/layout/ContentPane",
	"dijit/layout/TabContainer",
	"dijit/form/TextBox",
	"dijit/form/Button",
	"dijit/form/MultiSelect",
	"dijit/form/ValidationTextBox",
	"dijit/form/NumberTextBox",
	"dijit/form/CheckBox",
	"dijit/form/DateTextBox",
	"dijit/form/RadioButton",
	"ecm/widget/HoverHelp",
	"dojox/form/CheckedMultiSelect",
	"dojox/widget/TitleGroup",
	"dijit/TitlePane",
	"fEPUtilityPluginDojo/DeleteActionPopupDialog",
	"fEPUtilityPluginDojo/SYSIDActionPopupDialog",
	"fEPUtilityPluginDojo/DocStatActionPopupDialog",
	"fEPUtilityPluginDojo/DocTypActionPopupDialog",
	"fEPUtilityPluginDojo/YRJulianDateActionPopupDialog",
	"fEPUtilityPluginDojo/RecDateActionPopupDialog",
	"fEPUtilityPluginDojo/ComboChangeActionPopupDialog",
	"ecm/model/Request",
	"ecm/model/ResultSet",
	"ecm/widget/layout/_LaunchBarPane",
	"ecm/widget/layout/_RepositorySelectorMixin",
	"ecm/widget/listView/ContentList",
	"ecm/widget/listView/gridModules/RowContextMenu",
	"ecm/widget/listView/modules/Toolbar2",
	"ecm/widget/listView/modules/DocInfo",
	"ecm/widget/listView/gridModules/DndRowMoveCopy",
	"ecm/widget/listView/gridModules/DndFromDesktopAddDoc",
	"ecm/widget/listView/modules/Bar",
	"ecm/widget/listView/modules/ViewDetail",
	"ecm/widget/listView/modules/ViewMagazine",
	"ecm/widget/listView/modules/ViewFilmStrip",
	"dojo/text!./templates/FEPUtilityFeaturePane.html"
],

function(declare,
		lang,
		domAttr,
		dom,
		domStyle,
		registry,
		domConstruct,
		array,
		focus,
		Dialog,
		idxBorderContainer,
		ContentPane,
		TabContainer,
		TextBox,
		Button,
		MultiSelect,
		ValidationTextBox,
		NumberTextBox,
		CheckBox,
		DateTextBox,
		RadioButton,
		HoverHelp,
		CheckedMultiSelect,
		TitleGroup,
		TitlePane,
		DeleteActionPopupDialog,
		SYSIDActionPopupDialog,
		DocStatActionPopupDialog,
		DocTypActionPopupDialog,
		YRJulianDateActionPopupDialog,
		RecDateActionPopupDialog,
		ComboChangeActionPopupDialog,
		Request,
		ResultSet,
		_LaunchBarPane,
		_RepositorySelectorMixin,
		ContentList,
		RowContextMenu,
		Toolbar,
		DocInfo,
		DndRowMoveCopy,
		DndFromDesktopAddDoc,
		Bar,
		ViewDetail,
		ViewMagazine,
		ViewFilmStrip,
		template) {

	/**
	 * @name fEPUtilityPluginDojo.FEPUtilityFeaturePane
	 * @class Provides a pane that demonstrates how to insert new features into the standard IBM Content Navigator layout.
	 * @augments ecm.widget.layout._LaunchBarPane, ecm.widget.layout._RepositorySelectorMixin
	 */
	return declare("fEPUtilityPluginDojo.FEPUtilityFeaturePane", [
		_LaunchBarPane,
		_RepositorySelectorMixin
	], {
		/** @lends fEPUtilityPluginDojo.FEPUtilityFeaturePane.prototype */

		templateString: template,
		widgetsInTemplate: true,
		deleteActionPopupDialog : null,
		sYSIDActionPopupDialog: null,
		docstatActionPopupDialog:null,
		doctypActionPopupDialog:null,
		yRJuliandateActionPopupDialog:null,
		recdateActionPopupDialog:null,
		comboChangeActionPopupDialog:null,
		
		search_query_fields_names:null,
		document_Classes_ParentClass:null,
		Date_Criteria_object:null,
		STATE_object:null,
		SRCID_object:null,
		RTNCD_object:null,
		DOCUMENT_CLASS_object:null,
		STATUS_object:null,
		DOCTYPE_object:null,

		postCreate: function() {
			this.logEntry("postCreate - STARTED");
			this.inherited(arguments);
			
			domAttr.set(this.searchResults.domNode, "role", "region");
			domAttr.set(this.searchResults.domNode, "aria-label", this.messages.browse_content_list_label);
			this.searchResults.setContentListModules(this.getContentListModules());
			this.searchResults.setGridExtensionModules(this.getContentListGridModules());
			
			this.defaultLayoutRepositoryComponent = "others";
			this.setRepositoryTypes("cm,p8");
			this.createRepositorySelector();
			this.doRepositorySelectorConnections();
			
			// If there is more than one repository in the list, show the selector to the user.
			if (this.repositorySelector.getNumRepositories() > 1) {
				domConstruct.place(this.repositorySelector.domNode, this.repositorySelectorArea, "only");
			}
			

			this.member.setHoverHelp(this.memberId_HoverHelp);
			this.member.pattern = '^[a-zA-Z0-9]+$';
			this.member.invalidMessage = "alpha-numaric values allowed, length should be no more than 17";
			
			this.from_Claim.setHoverHelp(this.from_Claim_HoverHelp);
			this.from_Claim.pattern = '^[a-zA-Z0-9*]+$';
			this.from_Claim.invalidMessage = "* and alpha-numaric values are allowed, length should be no more than 17, Allowed wild card search";
			
			this.from_DCN.setHoverHelp(this.from_DCN_HoverHelp);
			this.from_DCN.pattern = '^[0-9]+$';
			this.from_DCN.invalidMessage = "Numaric values allowed, length should be no more than 17";
			
			this.thru_Claim.setHoverHelp(this.thru_Claim_HoverHelp);
			this.thru_Claim.pattern = '^[a-zA-Z0-9]+$';
			this.thru_Claim.invalidMessage = "Alpha-numaric values are allowed, length should be no more than 17";
			
			this.thru_DCN.setHoverHelp(this.thru_DCN_HoverHelp);
			this.thru_DCN.pattern = '^[0-9]+$';
			this.thru_DCN.invalidMessage = "Numaric values allowed, length should be no more than 17";
			
			this.mail_Tracking.setHoverHelp(this.mail_Tracking_HoverHelp);
			this.mail_Tracking.pattern = '^[a-zA-Z0-9%]+$';
			this.mail_Tracking.invalidMessage = "% and alpha-numaric values are allowed, length should be no more than 25, Allowed wild card search";
			
			this.corCheck.setHoverHelp(this.corCheck_HoverHelp);
			this.corCheck.pattern = '^[0-9]+$';
			this.corCheck.invalidMessage = "Numaric values allowed, length should be no more than 15";
			
			this.doc_id.setHoverHelp(this.doc_id_HoverHelp);
			this.doc_id.pattern = '^[0-9]+$';
			this.doc_id.invalidMessage = "Numaric values allowed, length should be no more than 10";

			this.npi.setHoverHelp(this.doc_id_HoverHelp);
			this.npi.pattern = '^[0-9]+$';
			this.npi.invalidMessage = "Numaric values allowed, length should be no more than 10";
			
			this.provider_number.setHoverHelp(this.provider_number_HoverHelp);
			this.provider_number.pattern = '^[a-zA-Z0-9]+$';
			this.provider_number.invalidMessage = "alpha-numaric values allowed, length should be no more than 16";
			
			this.batch_name.setHoverHelp(this.batch_name_HoverHelp);
			this.batch_name.pattern = '^[a-zA-Z0-9]+$';
			this.batch_name.invalidMessage = "alpha-numaric values allowed, length should be no more than 16";
			
			this.logExit("postCreate - ENDED");
		},
		
		convertUpperCase:function(event){
	        this.member.set("value",this.member.get("value").toUpperCase()); 
	        this.from_Claim.set("value",this.from_Claim.get("value").toUpperCase());
	        this.thru_Claim.set("value",this.thru_Claim.get("value").toUpperCase());
		},
		
		
		/**
		 * Sets the repository being used for search.
		 * 
		 * @param repository
		 * 			An instance of {@link ecm.model.Repository}
		 */
		setRepository: function(repository) {
			this.repository = repository;
			if (this.repositorySelector && this.repository) {
				this.repositorySelector.getDropdown().set("value", this.repository.id);
				/*if (this.repository.type == "cm") {
					domStyle.set(this.p8HelpText, "display", "none");
					domStyle.set(this.cm8HelpText, "display", "inline");
				} else if (this.repository.type == "p8") {
					domStyle.set(this.cm8HelpText, "display", "none");
					domStyle.set(this.p8HelpText, "display", "inline");
				}*/
			}
			this.clear();
		},
		
		/**
		 * Returns the content list grid modules used by this view.
		 * 
		 * @return Array of grid modules.
		 */
		getContentListGridModules: function() {
			var array = [];
			array.push(DndRowMoveCopy);
			array.push(DndFromDesktopAddDoc);
			array.push(RowContextMenu);
			return array;
		},

		/**
		 * Returns the content list modules used by this view.
		 * 
		 * @return Array of content list modules.
		 */
		getContentListModules: function() {
			var viewModules = [];
			viewModules.push(ViewDetail);
			viewModules.push(ViewMagazine);
			if (ecm.model.desktop.showViewFilmstrip) {
				viewModules.push(ViewFilmStrip);
			}

			var array = [];
			array.push(DocInfo);
			array.push({
				moduleClass: Bar,
				top: [
					[
						[
							{
								moduleClass: Toolbar
							},
							{
								moduleClasses: viewModules,
								"className": "BarViewModules"
							}
						]
					]
				]
			});
			return array;
		},

		/**
		 * Loads the content of the pane. This is a required method to insert a pane into the LaunchBarContainer.
		 */
		loadContent: function() {
			this.logEntry("loadContent");
			if (!this.repository) {
				this.setPaneDefaultLayoutRepository();
			} else if (!this.isLoaded && this.repository && this.repository.connected) {
				this.setRepository(this.repository);
				this.isLoaded = true;
				this.needReset = false;
			}
			console.log("Before loadPopupInformation");
			this.loadPopupInformation();
			this.connect(this.dateSelecter, "onChange", "onDateSelecterChange");
			this.connect(this.from_Claim, "onKeyUp", "on_from_Claim_Change");
			this.logExit("loadContent");
		},
		

		
		loadPopupInformation: function() {
			var requestParams = {};
				requestParams.repositoryId = this.repository.id;
				requestParams.repositoryType = this.repository.type;
				Request.invokePluginService("FEPUtilityPlugin", "FEPLoadDataPluginService",
					{
						requestParams: requestParams,
						requestCompleteCallback: lang.hitch(this, function(response) {	
							var _self = this;
							_self.search_query_fields_names = response.PrePopulatedData.search_query_fields_names;
							_self.document_Classes_ParentClass = response.PrePopulatedData.document_Classes_ParentClass;
							_self.Date_Criteria_object = response.PrePopulatedData.Date_Criteria;
							_self.STATE_object = response.PrePopulatedData.STATE;
							_self.SRCID_object = response.PrePopulatedData.SRCID;
							_self.RTNCD_object = response.PrePopulatedData.RTNCD;
							_self.DOCUMENT_CLASS_object = response.PrePopulatedData.DOCUMENT_CLASS;
							_self.STATUS_object = response.PrePopulatedData.STATUS;
							_self.DOCTYPE_object = response.PrePopulatedData.DOCTYPE;
							_self.loadDateSelecterValues();
							_self.constructMultiSelectCheckboxes(_self.stateTable, response.PrePopulatedData.STATE,"STATE");
							_self.constructMultiSelectCheckboxes(_self.SRCIDTable, response.PrePopulatedData.SRCID,"SRCID");
							_self.constructMultiSelectCheckboxes(_self.RtnCdTable, response.PrePopulatedData.RTNCD,"RTNCD");
							_self.constructMultiSelectCheckboxes(_self.docClassTable, response.PrePopulatedData.DOCUMENT_CLASS,"DOCUMENT_CLASS");
							_self.constructMultiSelectCheckboxes(_self.statusTable, response.PrePopulatedData.STATUS,"STATUS");
							_self.constructMultiSelectCheckboxes(_self.docTypeTable, response.PrePopulatedData.DOCTYPE,"DOCTYPE");
							console.log(response);
							console.log(_self.search_query_fields_names);
						})
					}
				);
		},
		constructMultiSelectCheckboxes:function(tableNode,items,identifier){
			var _self = this;
			var item_details = items.details;
			 
              if (item_details && item_details.length) {
            	  array.forEach(item_details, function (item) {
            		  var trAppend = domConstruct.create("tr");
        			  domAttr.set(trAppend, "class", "test");
            		  var tdAppend = domConstruct.create("td");
            		   var appendCheckBox = new dijit.form.CheckBox({
            			   name:identifier+"_"+item.id+"_append",
            			   id:identifier+"_"+item.id,
            			   value:item.value,
            			   checked:false,
            			   onClick:function () {
            				   _self.onAppendClick(identifier+"_"+item.id, item.value, this.get("checked"));
                       }});
                       tdAppend.appendChild(appendCheckBox.domNode);
                      
                      domConstruct.create("label", {"for":item.id, innerHTML:item.value}, tdAppend);
                      trAppend.appendChild(tdAppend);
                      tableNode.appendChild(trAppend);
                  });
              }
              if(identifier.includes("DOCUMENT_CLASS")){
            	  var node = registry.byId("DOCUMENT_CLASS_All");
      			  node.set("checked", true);
      			this.onAppendClick("DOCUMENT_CLASS_All","All",true);
              }
              
		},
		onAppendClick:function(id,value,isChecked){
			console.log(id + "  :  "+value + " : "+isChecked);
			var ids = this.DOCUMENT_CLASS_object.id_values;
			if (ids != null && ids.length>0 && id.includes("DOCUMENT_CLASS_") 
					&& (value == "All") && this.DOCUMENT_CLASS_object != null){
				if(isChecked)
					this.enable_disable_checkboxes("DOCUMENT_CLASS_",ids,value,true,true);
				else
					this.enable_disable_checkboxes("DOCUMENT_CLASS_",ids,value,false,false);
			}else if(ids != null && ids.length>0 && id.includes("DOCUMENT_CLASS_") 
					&& (value != "All") && this.DOCUMENT_CLASS_object != null){
				this.enable_disable_checkboxes_Other("DOCUMENT_CLASS_",ids,value,false,false);
			}
		},
		
		enable_disable_checkboxes_Other:function(idTag, ids, value, isChecked,isDisabed){
			console.log(idTag);
			var isAllchecksSelected = false;
			
			for (var i = 0; i < ids.length; i++) {
				if(!ids[i].includes("All")) {
                	console.log("test : "+(idTag + ids[i]));
                	var node = registry.byId(idTag + ids[i]);
					isAllchecksSelected = node.get("checked");
					if (!isAllchecksSelected)
						break;
                }
            }
			if(isAllchecksSelected){
				var node = registry.byId("DOCUMENT_CLASS_All");
    			  node.set("checked", true);
    			this.onAppendClick("DOCUMENT_CLASS_All","All",true);
			}
		},
		
		enable_disable_checkboxes:function(idTag, ids, value, isChecked,isDisabed){
			array.forEach(ids, function (id_val) {
				console.log(value +" : "+id_val)
      		  if(!value.includes(id_val)){
      			  var node = registry.byId(idTag+id_val);
      			  node.set("checked", isChecked);
      			  node.set("disabled", isDisabed);
      		  }
            });
		},
		
		loadDateSelecterValues:function(){
			var items = this.Date_Criteria_object.details;
			var options = new Array();
			array.forEach(items, function (item) {
				var option = {label:item.label, value:item.value};
                options.push(option);
            });
			this.dateSelecter.addOption(options);
		},
		
		
		on_from_Claim_Change:function(){
			var from_ClaimVal = this.from_Claim.get("value");
			if(!this.isEmpty(from_ClaimVal) && from_ClaimVal.includes("*")){
				this.thru_Claim.set("readOnly",true);
				this.thru_Claim.set("disabled",true);
			}else{
				this.thru_Claim.set("readOnly",false);
				this.thru_Claim.set("disabled",false);
			}
		},
		onDateSelecterChange:function(){
			console.log(this.dateSelecter.get("value"));
			console.log(this.startDate.get("value"));
			console.log(this.endDate.get("value"));
			console.log(this.dateCreated.get("value"));
			var dateSelecterVal = this.dateSelecter.get("value")
			if(!this.isEmpty(dateSelecterVal)){
				 if(dateSelecterVal == "Specific_Dates"){
					  this.startDate.set("readOnly",false);
					  this.endDate.set("readOnly",false);
				      this.startDate.set("disabled",false);
				      this.endDate.set("disabled",false);
			      }else{
			    	  this.startDate.set("readOnly",true);
					  this.endDate.set("readOnly",true);
				      this.startDate.set("disabled",true);
				      this.endDate.set("disabled",true);
			      }
			}
			
		},
		
		isEmpty: function(value){
			if(value == null || value == "")
				return true;
			else
				return false;
		},
		
		isValidDate: function(date){
			if(date != null && date.getFullYear().toString().length>0)
				return true;
			else
				return false;
		},
		
		
		

		/**
		 * Resets the content of this pane.
		 */
		reset: function() {
			this.logEntry("reset");
			
			if (this.repositorySelector && this.repository)
				this.repositorySelector.getDropdown().set("value", this.repository.id);
			this.needReset = false;
			
			this.logExit("reset");
		},
		
		/**
		 * Runs the search entered by the user.
		 */
		executeQueryAction: function() {
			var requestParams = {};
			var isValidated = this.validateFormFields();
			if(isValidated){
				requestParams.repositoryId = this.repository.id;
				requestParams.repositoryType = this.repository.type;
				//requestParams.member = this.member.get("value");
				//requestParams.docClass = this.docClass.get("value");
				
				requestParams.query = this.prepareQuery();
				console.log(requestParams.query);
				//requestParams.query = "Select * from FEP_CLAIMS";
				Request.invokePluginService("FEPUtilityPlugin", "FEPUtilityPluginSearchService",
					{
						requestParams: requestParams,
						requestCompleteCallback: lang.hitch(this, function(response) {	
							response.repository = this.repository;
							console.log(response);
							var resultSet = new ResultSet(response);
							this.searchResults.setResultSet(resultSet);
							this.NoOfResults.innerHTML=resultSet.items.length;
						})
					}
				);
			}else{
				console.log("validation failed");
				return;
			}
			
		},
		
		getValueFromMultiselection:function (object, identifier){
			var ids = object.id_values;
			var values = "";
			array.forEach(ids, function (id_val) {
      			  var node = registry.byId(identifier+"_"+id_val);
      			  if(node.get("checked") && node.get("value")){
      				values = values + id_val + ",";
      			  }
            });
			values = values.substring(0,values.length-1);
			return values;
		},

		prepareQuery: function(){
			console.log("into prepareQuery method");
			var currentDate = new Date();
			var query = "Select * from ";
			var query_options = " OPTIONS(TIMELIMIT 1800)";
			var member = this.member.get("value");
			var from_Claim = this.from_Claim.get("value");
			var thru_Claim = this.thru_Claim.get("value");
			var from_DCN = this.from_DCN.get("value");
			var thru_DCN = this.thru_DCN.get("value");
			var mail_Tracking = this.mail_Tracking.get("value");
			var corCheck = this.corCheck.get("value");
			var doc_id = this.doc_id.get("value");
			var provider_number = this.provider_number.get("value");
			var npi = this.npi.get("value");
			var batch_name = this.batch_name.get("value");
			var dateSelecter = this.dateSelecter.get("value");
			var startDate = this.startDate.get("value");
			var endDate = this.endDate.get("value");
			var dateCreated = this.dateCreated.get("value");
			//this is not included
			var All = this.All.get("value");
			var GHI = this.GHI.get("value");
			var NonGHI = this.NonGHI.get("value");
			console.log("prepareQuery : "+All +" : "+GHI +" : "+NonGHI);
			var document_class_Selection_Values = this.getValueFromMultiselection(this.DOCUMENT_CLASS_object, "DOCUMENT_CLASS");
			var state_Selection_Values = this.getValueFromMultiselection(this.STATE_object, "STATE");
			var srcid_Selection_Values = this.getValueFromMultiselection(this.SRCID_object, "SRCID");
			var rtncd_Selection_Values = this.getValueFromMultiselection(this.RTNCD_object, "RTNCD");
			var status_Selection_Values = this.getValueFromMultiselection(this.STATUS_object,"STATUS");
			var docType_Selection_Values = this.getValueFromMultiselection(this.DOCTYPE_object, "DOCTYPE");
			console.log(" document_class_Selection_Values : "+document_class_Selection_Values);
			console.log(" state_Selection_Values : "+state_Selection_Values);
			console.log(" srcid_Selection_Values : "+srcid_Selection_Values);
			console.log(" rtncd_Selection_Values : "+rtncd_Selection_Values);
			console.log(" status_Selection_Values : "+status_Selection_Values);
			console.log(" docType_Selection_Values : "+docType_Selection_Values);
			
			if(document_class_Selection_Values.includes("All")){
				query = query + this.document_Classes_ParentClass+" where ";
			}else{
				query = query + document_class_Selection_Values+" where ";
			}
			if(!this.isEmpty(member) &&  member.trim().length>0)
				query = query + " ( "+this.search_query_fields_names.member+" = '"+member.trim()+"' ) AND";
			
			if(!this.isEmpty(from_Claim) && from_Claim.includes("*")){
				query = query + " ( "+this.search_query_fields_names.from_Claim+"  like '"+from_Claim.trim()+"%') AND";
			}
			if(!this.isEmpty(from_Claim) && !from_Claim.includes("*")){
				query = query + " ( "+this.search_query_fields_names.from_Claim+" ='"+from_Claim.trim()+"' ) AND";
			}
			
			if(!this.isEmpty(from_DCN) && from_DCN.trim().length>0){
				query = query + " ( "+this.search_query_fields_names.from_DCN+" ='"+from_DCN.trim()+"' ) AND";
			}
			
			if(!this.isEmpty(thru_Claim) &&  thru_Claim.trim().length>0 && !from_Claim.includes("*")){
				query = query + " ( "+this.search_query_fields_names.thru_Claim+" ='"+thru_Claim.trim()+"' ) AND";
			}
			
			if(!this.isEmpty(thru_DCN) && thru_DCN.trim().length>0){
				query = query + " ( "+this.search_query_fields_names.thru_DCN+" ='"+thru_DCN.trim()+"' ) AND";
			}
			
			if(!this.isEmpty(mail_Tracking) &&  mail_Tracking.trim().length>0){
				if(mail_Tracking.includes("%"))
					query = query + " ( "+this.search_query_fields_names.mail_Tracking+" like '%"+mail_Tracking.trim()+"%' ) AND";
				else
					query = query + " ( "+this.search_query_fields_names.mail_Tracking+" ='"+mail_Tracking.trim()+"' ) AND";
			}
			if(!this.isEmpty(corCheck) &&  corCheck.trim().length>0){
				query = query + " ( "+this.search_query_fields_names.corCheck+" ='"+corCheck.trim()+"' ) AND";
			}
			if(!this.isEmpty(doc_id) &&  doc_id.trim().length>0){
				query = query + " ( "+this.search_query_fields_names.member+" ='"+doc_id.trim()+"') AND";
			}
			if(!this.isEmpty(provider_number) &&  provider_number.trim().length>0){
				query = query + " ( "+this.search_query_fields_names.doc_id+" ='"+provider_number.trim()+"' ) AND";
			}
			if(!this.isEmpty(npi) &&  npi.trim().length>0){
				query = query + " ( "+this.search_query_fields_names.npi+" ='"+npi.trim()+"' ) AND";
			}
			if(!this.isEmpty(batch_name) &&  batch_name.trim().length>0){
				query = query + " ( "+this.search_query_fields_names.batch_name+" ='"+batch_name.trim()+"' ) AND";
			}
			
			if(!this.isEmpty(dateSelecter) &&  dateSelecter.trim().length>0){
				console.log(startDate);
				console.log(endDate);
				if(dateSelecter != "ALL Dates" && dateSelecter == "Specific_Dates" &&
						this.isValidDate(startDate) && this.isValidDate(endDate)){
					query = query + " ("+this.search_query_fields_names.dateSelecter+" >= '"+this.getDateString(startDate,true)+"' AND" +
							" "+this.search_query_fields_names.dateSelecter+" <= '"+this.getDateString(endDate,false)+"') AND ";
				}
				if(dateSelecter != "ALL Dates" && dateSelecter == "001-012 Mos"){
					var _sDate = new Date(currentDate.getFullYear(), 0, 1);
					var _eDate = new Date(currentDate.getFullYear(), 11, 31);
					query = query + " ("+this.search_query_fields_names.dateSelecter+" >= '"+this.getDateString(_sDate,true)+"' AND" +
							" "+this.search_query_fields_names.dateSelecter+" <= '"+this.getDateString(_eDate,false)+"') AND ";
				}
			}
			if(this.isValidDate(dateCreated)){
				query = query + " ("+this.search_query_fields_names.dateCreated+" >= '"+this.getDateString(dateCreated,true)+"' AND " +
						""+this.search_query_fields_names.dateCreated+" <= '"+this.getDateString(dateCreated,false)+"' ) AND ";
			}
			
			/*if((!this.isEmpty(All) &&  All.trim().length>0) || 
					(!this.isEmpty(GHI) &&  GHI.trim().length>0) || 
					(!this.isEmpty(NonGHI) &&  NonGHI.trim().length>0)){
				query = query + " ( "+this.search_query_fields_names.get("GHI_And_NON_GHI")+" ='"+batch_name.trim()+"' ) AND";
			}*/
			
			
		
			if(!this.isEmpty(state_Selection_Values) &&  state_Selection_Values.trim().split(",").length>0){
				query = query + " ( "+this.search_query_fields_names.STATE+" IN ("+this.prepareMultiString(state_Selection_Values.trim().split(","))+") ) AND";
			}
			if(!this.isEmpty(srcid_Selection_Values) &&  srcid_Selection_Values.trim().split(",").length>0){
				query = query + " ( "+this.search_query_fields_names.SRCID+" IN ("+this.prepareMultiString(srcid_Selection_Values.trim().split(","))+") ) AND";
			}
			if(!this.isEmpty(rtncd_Selection_Values) &&  rtncd_Selection_Values.trim().split(",").length>0){
				query = query + " ( "+this.search_query_fields_names.RTNCD+" IN ("+this.prepareMultiString(rtncd_Selection_Values.trim().split(","))+") ) AND";
			}
			if(!this.isEmpty(status_Selection_Values) &&  status_Selection_Values.trim().split(",").length>0){
				query = query + " ( "+this.search_query_fields_names.STATUS+" IN ("+this.prepareMultiString(status_Selection_Values.trim().split(","))+") ) AND";
			}
			if(!this.isEmpty(docType_Selection_Values) &&  docType_Selection_Values.trim().split(",").length>0){
				query = query + " ( "+this.search_query_fields_names.DOCTYPE+" IN ("+this.prepareMultiString(docType_Selection_Values.trim().split(","))+") ) AND";
			}
			
			
			if(query.includes("where")){
				var temp = query.split("where")[1];
				console.log(temp)
				if(temp.trim().length>0){
					query = query.substr(0, query.lastIndexOf("AND")) + '';
				}else{
					query = query.substr(0, query.lastIndexOf("where")) + '';
				}
			}
			
			query = query.trim() + query_options;
			return query;
		},
		
		prepareMultiString:function(tokens){
			var _str = "'"
			array.forEach(tokens, function (token) {
				_str = _str + token + "','";
            });
			_str = _str.substr(0,_str.length-2);
			console.log(_str);
			return _str;
		},
		
		getDateString:function(date, flag){
			console.log("date value : ",date);
			var dateString = "";
			date.setDate(date.getDate() + 1);
			console.log("date value : ",date);
			if(flag){
				date.setUTCHours(0,0,0,0);
			}else{
				date.setUTCHours(23,59,59,999)
			}
			var _DateTime = date.toISOString();
			_DateTime  = _DateTime.replace(/[-:]/g, "");
			dateString = _DateTime.substr(0,_DateTime.indexOf("."))+"Z";
			return dateString;
		},
		
		validateFormFields: function(){
			var member = this.member.get("value");
			var from_Claim = this.from_Claim.get("value");
			var thru_Claim = this.thru_Claim.get("value");
			var from_DCN = this.from_DCN.get("value");
			var thru_DCN = this.thru_DCN.get("value");
			var mail_Tracking = this.mail_Tracking.get("value");
			var corCheck = this.corCheck.get("value");
			var doc_id = this.doc_id.get("value");
			var provider_number = this.provider_number.get("value");
			var npi = this.npi.get("value");
			var batch_name = this.batch_name.get("value");
			var dateSelecter = this.dateSelecter.get("value");
			var startDate = this.startDate.get("value");
			var endDate = this.endDate.get("value");
			var dateCreated = this.dateCreated.get("value");
			var All = this.All.get("value");
			var GHI = this.GHI.get("value");
			var NonGHI = this.NonGHI.get("value");
			var document_class_Selection_Values = this.getValueFromMultiselection(this.DOCUMENT_CLASS_object, "DOCUMENT_CLASS");
			var state_Selection_Values = this.getValueFromMultiselection(this.STATE_object, "STATE");
			var srcid_Selection_Values = this.getValueFromMultiselection(this.SRCID_object, "SRCID");
			var rtncd_Selection_Values = this.getValueFromMultiselection(this.RTNCD_object, "RTNCD");
			var status_Selection_Values = this.getValueFromMultiselection(this.STATUS_object,"STATUS");
			var docType_Selection_Values = this.getValueFromMultiselection(this.DOCTYPE_object, "DOCTYPE");
			
			var isAllchecksSelected = false;
			var ids = this.DOCUMENT_CLASS_object.id_values;
			
			console.log(member);
			console.log(from_Claim);
			console.log(thru_Claim);
			console.log(from_DCN);
			console.log(thru_DCN);
			console.log(mail_Tracking);
			console.log(corCheck);
			console.log(doc_id);
			console.log(provider_number);
			console.log(npi);
			console.log(batch_name);
			console.log(dateSelecter);
			console.log(startDate);
			console.log(endDate);
			console.log(dateCreated);
			console.log(All);
			console.log(GHI);
			console.log(NonGHI);
			
			console.log(state_Selection_Values);
			console.log(srcid_Selection_Values);
			console.log(rtncd_Selection_Values);
			console.log(status_Selection_Values);
			console.log(docType_Selection_Values);
			
			
			
			if( document_class_Selection_Values != null && document_class_Selection_Values.length>0){
				
				if(member != null && member.length>0){
					if(!this.onlyLettersAndDigits(member))
					{
						this.alertContent.innerHTML = "Enter valid Member ID";
						this.dialogColor.show();
						focus.focus(this.member);
						return false;
					}
				}
				if(from_Claim != null && from_Claim.length>0){
					if(!this.onlyLettersAndDigitsWithStar(from_Claim)){
						this.alertContent.innerHTML = "Enter valid From Claim";
						this.dialogColor.show();
						focus.focus(this.from_Claim);
						return false;
					}
				}
				if(thru_Claim != null && thru_Claim.length>0){
					if(this.onlyLettersAndDigits(thru_Claim)){
						this.alertContent.innerHTML = "Enter valid Thru Claim";
						this.dialogColor.show();
						focus.focus(this.thru_Claim);
						return false;
					}
				}
				if(thru_DCN != null && from_DCN.length>0){
					if(!this.onlyDigits(from_DCN)){
						this.alertContent.innerHTML = "Enter valid From DCN";
						this.dialogColor.show();
						focus.focus(this.from_Claim);
						return false;
					}
				}
				if( thru_DCN != null && thru_DCN.length>0){
					if(!this.onlyDigits(thru_DCN)){
						this.alertContent.innerHTML = "Enter valid Thru DCN";
						this.dialogColor.show();
						focus.focus(this.thru_Claim);
						return false;
					}
				}
				if( mail_Tracking != null && mail_Tracking.length>0){
					if(this.onlyLettersAndDigits(mail_Tracking)){
						this.alertContent.innerHTML = "Enter valid Mail Tracking";
						this.dialogColor.show();
						focus.focus(this.mail_Tracking);
						return false;
					}
				}
				if( corCheck != null && corCheck.length>0){
					if(this.onlyDigits(corCheck)){
						this.alertContent.innerHTML = "Enter valid COR Check";
						this.dialogColor.show();
						focus.focus(this.corCheck);
						return false;
					}
				}
				if( doc_id != null && doc_id.length>0){
					if(this.onlyDigits(doc_id)){
						this.alertContent.innerHTML = "Enter valid DOCID";
						this.dialogColor.show();
						focus.focus(this.doc_id);
						return false;
					}
				}
				if( npi != null && npi.length>0){
					if(this.onlyDigits(npi)){
						this.alertContent.innerHTML = "Enter valid provider number";
						this.dialogColor.show();
						focus.focus(this.provider_number);
						return false;
					}
				}
				
				/*for (var i = 0; i < ids.length; i++) {
	                	var node = registry.byId("DOCUMENT_CLASS_" + ids[i]);
						isAllchecksSelected = node.get("checked");
						if (isAllchecksSelected)
							break;
	                
	            }
				if(!isAllchecksSelected){
					this.alertContent.innerHTML = "Please select at least one document class";
					this.dialogColor.show();
					return false;
				}else{
					isValidated = true;
				}*/
				return true;
			}else{
				this.alertContent.innerHTML = "Please select at least one document class";
				this.dialogColor.show();
				return false;
			}
		},
		
		closePopupDialog:function(){
			this.dialogColor.hide();
		},
		
		onlyLettersAndDigits: function(inputtxt){
			var letterNumber = /^[0-9a-zA-Z]+$/;
			if (inputtxt.match(letterNumber)) {
				return true;
			} else {
				return false;
			}
		},
		
		onlyDigits: function(inputtxt){
			var letterNumber = /^[0-9]+$/;
			if (inputtxt.match(letterNumber)) {
				return true;
			} else {
				return false;
			}
		},
		
		onlyLettersAndDigitsWithStar: function(inputtxt){
			var letterNumber = /^[0-9a-zA-Z*]+$/;
			if (inputtxt.match(letterNumber)) {
				return true;
			} else {
				return false;
			}
		},
		
		
		clearFormAction: function() {},
		

		/**
		 * Clears the search results.
		 */
		clear: function() {
			//this.queryString.set("value", "");
			this.searchResults.reset();
		}
	});
});
