

define(["dojo/_base/declare", "ecm/model/Action"],
	function(declare, Action) {

	return declare("fEPUtilityPluginDojo.AnnotationAction", [ Action ], {
	/** @lends fEPUtilityPluginDojo.AnnotationAction.prototype */
	
		/**
		 * Returns true if this action should be enabled for the given repository, list type, and items.
		 */
		isEnabled: function(repository, listType, items, teamspace, resultSet) {
			var enabled = this.inherited(arguments);
			if (items[0].hasContent) {
				enabled &= items[0].hasContent();
			} else {
				enabled = false;
			}
			return enabled;
		},
	
		/**
		 * Returns true if this action should be visible for the given repository and list type.
		 */
		isVisible: function(repository, listType) {
			return this.inherited(arguments);
		}
	});
});