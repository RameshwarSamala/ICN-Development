
define([
		"dojo/_base/declare",
		"dijit/form/Select",
		"ecm/widget/dialog/BaseDialog",
		"dojo/text!./templates/AnnotationPopupDialog.html"
	],
	function(declare, Select, BaseDialog, template) {

	/**
	 * @name fEPUtilityPluginDojo.AnnotationPopupDialog
	 * @class Provides a dialog whose main content is an html page displayed in an iframe.  
	 * @augments ecm.widget.dialog.BaseDialog
	 */
	return declare("fEPUtilityPluginDojo.AnnotationPopupDialog", [ BaseDialog ], {
	/** @lends fEPUtilityPluginDojo.AnnotationPopupDialog.prototype */	

		contentString: template,
		widgetsInTemplate: true,
		constructor:function (args) {
            if (args) {
                this._callback = args.callback;
            }
        },
		postCreate: function() {
			this.inherited(arguments);
			this.setResizable(true);
			this.setMaximized(true);
			this.setTitle("Document Annotations");
		},
        
        onCancel:function () {
        },
        
		show: function(repository,items) {
			console.log("repository : "+repository);
			console.log("items : "+items);
			this.inherited("show", []);
		}
	});
});
