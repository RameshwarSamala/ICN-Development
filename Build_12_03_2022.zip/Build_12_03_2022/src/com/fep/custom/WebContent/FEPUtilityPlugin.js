require(["dojo/_base/declare",
         "dojo/_base/lang",
         "fEPUtilityPluginDojo/AnnotationAction",
         "fEPUtilityPluginDojo/ShowImageAction",
         "fEPUtilityPluginDojo/ComboChangeAction",
         "fEPUtilityPluginDojo/DeleteAction",
         "fEPUtilityPluginDojo/DocStatAction",
         "fEPUtilityPluginDojo/DocTypAction",
         "fEPUtilityPluginDojo/RecDateAction",
         "fEPUtilityPluginDojo/SYSIDAction",
         "fEPUtilityPluginDojo/YRJulianDateAction",
         "fEPUtilityPluginDojo/AnnotationPopupDialog",
         "fEPUtilityPluginDojo/ComboChangeActionPopupDialog",
         "fEPUtilityPluginDojo/DeleteActionPopupDialog",
         "fEPUtilityPluginDojo/DocStatActionPopupDialog",
         "fEPUtilityPluginDojo/DocTypActionPopupDialog",
         "fEPUtilityPluginDojo/RecDateActionPopupDialog",
         "fEPUtilityPluginDojo/SYSIDActionPopupDialog",
         "fEPUtilityPluginDojo/YRJulianDateActionPopupDialog",
         "fEPUtilityPluginDojo/SampleDecorator"], 
function(declare, lang,AnnotationAction,ShowImageAction,
		ComboChangeAction,DeleteAction,DocStatAction,
		DocTypAction,RecDateAction,SYSIDAction,YRJulianDateAction,
		AnnotationPopupDialog,ComboChangeActionPopupDialog,
		DeleteActionPopupDialog,DocStatActionPopupDialog,
		DocTypActionPopupDialog,RecDateActionPopupDialog,
		SYSIDActionPopupDialog,YRJulianDateActionPopupDialog,
		SampleDecorator) {		
	var annotationPopupDialog = null;
	var comboChangeActionPopupDialog = null;
	var deleteActionPopupDialog = null;
	var docStatActionPopupDialog = null;
	var docTypActionPopupDialog = null;
	var recDateActionPopupDialog = null;
	var sYSIDActionPopupDialog = null;
	var yRJulianDateActionPopupDialog = null;
	
	
	lang.setObject("fepUtilityPluginAnnotationAction", function(repository, items) {
		if (!annotationPopupDialog)
			annotationPopupDialog =  new AnnotationPopupDialog({callback:function (params) {
                console.log(params);
			}});
		
		annotationPopupDialog.show(repository,items);
	});
	
	lang.setObject("fepUtilityPluginComboChangeAction", function(repository, items) {
		console.log("ShowImage action called");
	});
	
	lang.setObject("fepUtilityPluginComboChangeAction", function(repository, items) {
		if (!comboChangeActionPopupDialog)
			comboChangeActionPopupDialog =  new ComboChangeActionPopupDialog({callback:function (params) {
                console.log(params);
			}});
		
		comboChangeActionPopupDialog.show(repository,items);
	});
	
	lang.setObject("fepUtilityPluginDeleteAction", function(repository, items) {
		if (!deleteActionPopupDialog)
			deleteActionPopupDialog =  new DeleteActionPopupDialog({callback:function (params) {
                console.log(params);
			}});
		
		deleteActionPopupDialog.show(repository,items);
	});
	
	lang.setObject("fepUtilityPluginDocStatAction", function(repository, items) {
		if (!docStatActionPopupDialog)
			docStatActionPopupDialog =  new DocStatActionPopupDialog({callback:function (params) {
                console.log(params);
			}});
		
		docStatActionPopupDialog.show(repository,items);
	});
	
	lang.setObject("fepUtilityPluginDocTypAction", function(repository, items) {
		if (!docTypActionPopupDialog)
			docTypActionPopupDialog =  new DocTypActionPopupDialog({callback:function (params) {
                console.log(params);
			}});
		
		docTypActionPopupDialog.show(repository,items);
	});
	
	lang.setObject("fepUtilityPluginRecDateAction", function(repository, items) {
		if (!recDateActionPopupDialog)
			recDateActionPopupDialog =  new RecDateActionPopupDialog({callback:function (params) {
                console.log(params);
			}});
		
		recDateActionPopupDialog.show(repository,items);
	});
	
	lang.setObject("fepUtilityPluginSYSIDAction", function(repository, items) {
		if (!sYSIDActionPopupDialog)
			sYSIDActionPopupDialog =  new SYSIDActionPopupDialog({callback:function (params) {
                console.log(params);
			}});
		
		sYSIDActionPopupDialog.show(repository,items);
	});
	
	lang.setObject("fepUtilityPluginYRJulianDateAction", function(repository, items) {
		if (!yRJulianDateActionPopupDialog)
			yRJulianDateActionPopupDialog =  new YRJulianDateActionPopupDialog({callback:function (params) {
                console.log(params);
			}});
		
		yRJulianDateActionPopupDialog.show(repository,items);
	});
	
	
});
