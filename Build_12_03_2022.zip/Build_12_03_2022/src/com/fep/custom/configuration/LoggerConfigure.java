package com.fep.custom.configuration;

public class LoggerConfigure {

}
