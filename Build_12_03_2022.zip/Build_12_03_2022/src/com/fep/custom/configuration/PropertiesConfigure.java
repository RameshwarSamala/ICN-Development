package com.fep.custom.configuration;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import com.fep.custom.constants.PluginConstants;
import com.ibm.ecm.extension.PluginLogger;
import com.ibm.ecm.extension.PluginServiceCallbacks;

public class PropertiesConfigure {
	public Properties props = null;
	PluginLogger logger = null;
	HttpServletRequest request = null;
	
	public PropertiesConfigure(PluginServiceCallbacks callbacks, HttpServletRequest request) {
		this.logger = callbacks.getLogger();
		this.request = request;
	}
	public Properties loadProperties(){
		String methodName = "loadProperties"; 
		logger.logEntry(this, methodName, request);
		InputStream is = null;
		try {
			props = new Properties(); 
			is = new FileInputStream(new File(PluginConstants.PROPERTIES_FILE_PATH));
			props.load(is);
			logger.logInfo(this, methodName, request, "Properties file got loaded success");
		} catch (FileNotFoundException fnf) {
			logger.logError(this, methodName, request, fnf);
		} catch (IOException ioe){
			logger.logError(this, methodName, request, ioe);
		}
		logger.logExit(this, methodName, request);
		return props;
	}
	public Properties getProperties(){
		if(props == null)
			loadProperties();
		return props;
	}
}
