/*
 * Licensed Materials - Property of IBM (c) Copyright IBM Corp. 2012, 2013 All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp.
 * 
 * DISCLAIMER OF WARRANTIES :
 * 
 * Permission is granted to copy and modify this Sample code, and to distribute modified versions provided that both the
 * copyright notice, and this permission notice and warranty disclaimer appear in all copies and modified versions.
 * 
 * THIS SAMPLE CODE IS LICENSED TO YOU AS-IS. IBM AND ITS SUPPLIERS AND LICENSORS DISCLAIM ALL WARRANTIES, EITHER
 * EXPRESS OR IMPLIED, IN SUCH SAMPLE CODE, INCLUDING THE WARRANTY OF NON-INFRINGEMENT AND THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL IBM OR ITS LICENSORS OR SUPPLIERS BE LIABLE FOR
 * ANY DAMAGES ARISING OUT OF THE USE OF OR INABILITY TO USE THE SAMPLE CODE, DISTRIBUTION OF THE SAMPLE CODE, OR
 * COMBINATION OF THE SAMPLE CODE WITH ANY OTHER CODE. IN NO EVENT SHALL IBM OR ITS LICENSORS AND SUPPLIERS BE LIABLE
 * FOR ANY LOST REVENUE, LOST PROFITS OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE
 * DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, EVEN IF IBM OR ITS LICENSORS OR SUPPLIERS HAVE
 * BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 */

package com.fep.custom.services;

import java.util.Date;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fep.custom.configuration.PropertiesConfigure;
import com.fep.custom.constants.PluginConstants;
import com.fep.custom.services.helper.FEPLoadDataHelper;
import com.ibm.ecm.extension.PluginResponseUtil;
import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import com.ibm.ecm.json.JSONResponse;
import com.ibm.json.java.JSONObject;

/**
 * This service is invoked by SamplePluginAction. It will invoke the OD, P8, CM or CMIS API's to obtain system-related
 * details about a document and return those details in JSON.
 */
public class FEPLoadDataPluginService extends PluginService {

	@Override
	public String getId() {
		return "FEPLoadDataPluginService";
	}

	@Override
	public void execute(PluginServiceCallbacks callbacks, HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		String methodName = "execute";
		callbacks.getLogger().logEntry(this, methodName, request);
		// Get the parameters.  (Note, you might want to add additional error handling for missing parameters.)
		String repositoryType = request.getParameter("repositoryType");
		String repositoryId = request.getParameter("repositoryId");
		callbacks.getLogger().logDebug(this, methodName, request, "repositoryType: " + repositoryType + ", repositoryId: " + repositoryId);
		try {
			Date date = callbacks.getLogger().logPerf(this, methodName, request);
			JSONResponse jsonResponse = new JSONResponse();
			 if (repositoryType.equals("p8")) {
				 new FEPLoadDataHelper().loadPopulateJsonData(request, jsonResponse, callbacks, repositoryId);
			} 
			// Write results to response
			PluginResponseUtil.writeJSONResponse(request, response, jsonResponse, callbacks, "FEPLoadDataPluginService");
			callbacks.getLogger().logPerf(this, methodName, request, date);

		} catch (Exception e) {
			// provide error information
			callbacks.getLogger().logError(this, methodName, request, e);
		}
		callbacks.getLogger().logExit(this, methodName, request);
	}

}
