package com.fep.custom.services.helper;

import java.util.Properties;
import javax.servlet.http.HttpServletRequest;
import com.fep.custom.configuration.PropertiesConfigure;
import com.fep.custom.constants.PluginConstants;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import com.ibm.ecm.json.JSONResponse;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;


public class FEPLoadDataHelper {

	public void loadPopulateJsonData(HttpServletRequest request, JSONResponse jsonResponse, 
			PluginServiceCallbacks callbacks, String repositoryId) throws Exception {
		Properties props = new PropertiesConfigure(callbacks,request).getProperties();
		String user_interface_search_fields = props.getProperty(PluginConstants.user_interface_search_fields);
		String json_Files_to_be_included = props.getProperty(PluginConstants.json_Files_to_be_included);
		String document_Classes_ParentClass = props.getProperty(PluginConstants.document_Classes_ParentClass);
		System.out.println("json_Files_to_be_included ::: "+json_Files_to_be_included);
		JSONObject _prePopulatedData = new JSONObject();
		if(json_Files_to_be_included != null && user_interface_search_fields != null){
			String [] json_Files = json_Files_to_be_included.split(",");
			System.out.println("json_Files length :: "+json_Files.length);
			for (int i = 0; i < json_Files.length; i++) {
				System.out.println("json_Files : "+json_Files[i]);
				try {
					if(json_Files[i].equalsIgnoreCase(PluginConstants.Date_Criteria))
						_prePopulatedData.put(json_Files[i], getJsonObject(props, json_Files[i]));
					if(json_Files[i].equalsIgnoreCase(PluginConstants.STATE))
						_prePopulatedData.put(json_Files[i], getJsonObject(props, json_Files[i]));
					if(json_Files[i].equalsIgnoreCase(PluginConstants.SRCID))
						_prePopulatedData.put(json_Files[i], getJsonObject(props, json_Files[i]));
					if(json_Files[i].equalsIgnoreCase(PluginConstants.RTNCD))
						_prePopulatedData.put(json_Files[i], getJsonObject(props, json_Files[i]));
					if(json_Files[i].equalsIgnoreCase(PluginConstants.DOCUMENT_CLASS))
						_prePopulatedData.put(json_Files[i], getJsonObject(props, json_Files[i]));
					if(json_Files[i].equalsIgnoreCase(PluginConstants.STATUS))
						_prePopulatedData.put(json_Files[i], getJsonObject(props, json_Files[i]));
					if(json_Files[i].equalsIgnoreCase(PluginConstants.DOCTYPE))
						_prePopulatedData.put(json_Files[i], getJsonObject(props, json_Files[i]));
				} catch (Exception e) {
					e.printStackTrace();
					callbacks.getLogger().logError(this, "loadPopulateJsonData", request, e);
				}
			}
		}
		_prePopulatedData.put("document_Classes_ParentClass", document_Classes_ParentClass);
		_prePopulatedData.put("search_query_fields_names", loadSearchQueryFields(props,user_interface_search_fields));
		
		jsonResponse.put("PrePopulatedData", _prePopulatedData);
	}
	
	private JSONObject loadSearchQueryFields(Properties props, String user_interface_search_fields) {
		JSONObject jsonDetails = new JSONObject();
		String fields [] = user_interface_search_fields.split(",");
		for (int i = 0; i < fields.length; i++) {
			jsonDetails.put(fields[i], props.getProperty(fields[i]+"_SymbolicName"));
		}
		return jsonDetails;
	}

	private JSONObject getJsonObject(Properties props, String propertyName){
		System.out.println( "loading properties for  : "+propertyName);
		JSONArray _json_values_array = new JSONArray();
		JSONArray _json_id_array = new JSONArray();
		JSONArray items_array = new JSONArray();
		JSONObject jsonDetails = new JSONObject();
    	String list = props.getProperty(propertyName+"_list");
    	if(list != null){
    		String list_values [] = list.split(",");
    		if(list_values != null && list_values.length>0){
    			for (int i = 0; i < list_values.length; i++) {
    				JSONObject _item = new JSONObject();
    				_item.put("value",list_values[i]);
    				_item.put("label",list_values[i]);
    				_item.put("id",list_values[i].trim().replace(" ","_"));
    				items_array.add(_item);
    				_json_values_array.add(list_values[i]);
    				_json_id_array.add(list_values[i].trim().replace(" ","_"));
    				
    			}
    		}
    	}
    	jsonDetails.put("list", _json_values_array);
    	jsonDetails.put("id_values", _json_id_array);
    	jsonDetails.put("details", items_array);
        return jsonDetails;	
	}
	

}
