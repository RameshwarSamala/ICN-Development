package com.fep.custom.services.helper;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.apache.struts.util.MessageResources;

import com.fep.custom.configuration.PropertiesConfigure;
import com.fep.custom.constants.PluginConstants;
import com.filenet.api.admin.ClassDefinition;
import com.filenet.api.admin.PropertyDefinition;
import com.filenet.api.collection.AnnotationSet;
import com.filenet.api.collection.CmThumbnailSet;
import com.filenet.api.collection.IndependentObjectSet;
import com.filenet.api.collection.PageIterator;
import com.filenet.api.collection.PropertyDefinitionList;
import com.filenet.api.constants.PropertyNames;
import com.filenet.api.constants.TypeID;
import com.filenet.api.core.CmThumbnail;
import com.filenet.api.core.Document;
import com.filenet.api.core.Factory;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.property.FilterElement;
import com.filenet.api.property.Properties;
import com.filenet.api.property.Property;
import com.filenet.api.property.PropertyFilter;
import com.filenet.api.query.SearchSQL;
import com.filenet.api.query.SearchScope;
import com.filenet.api.util.Id;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import com.ibm.ecm.json.JSONResultSetColumn;
import com.ibm.ecm.json.JSONResultSetResponse;
import com.ibm.ecm.json.JSONResultSetRow;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

/**
 * This class contains P8 specific logic for the sample plugin search service. It demonstrates running a search using
 * the P8 APIs and populating a JSONResultSetResponse object, which is used to populate the ecm.model.ResultSet
 * JavaScript model class. This class provides the structure and rows for the ecm.widget.listView.ContentList DOJO
 * widget.
 */
public class FEPUtilityPluginSearchServiceP8 {

	/**
	 * Runs the P8 search SQL
	 * 
	 * @param objectStore
	 *            Handle to the ObjectStore
	 * @param query
	 *            The query to run
	 * @param callbacks
	 *            The PluginServiceCallbacks object
	 * @param jsonResultSet
	 *            JSONResultSetResponse to build up the grid structure and rows.
	 * @param clientLocale
	 *            The locale of the client
	 * @param request 
	 */
	@SuppressWarnings("rawtypes")
	public static void executeP8Search(String repositoryId, String query, 
			PluginServiceCallbacks callbacks, JSONResultSetResponse jsonResultSet, Locale clientLocale, HttpServletRequest request) throws Exception {
		ObjectStore objectStore = callbacks.getP8ObjectStore(repositoryId);
		java.util.Properties props = new PropertiesConfigure(callbacks,request).getProperties();
		String resultSet_columns = props.getProperty(PluginConstants.resultSet_columns);
		
		buildP8ResultStructure(jsonResultSet, callbacks.getResources(), clientLocale,resultSet_columns,props);

		System.out.println("query :: "+query);
		SearchSQL searchSQL = new SearchSQL(query);
		SearchScope searchScope = new SearchScope(objectStore);

		// Use callbacks.getP8FolderResultsPropertyFilter() for folder results.
		PropertyFilter filter = callbacks.getP8DocumentResultsPropertyFilter();
		//
		// Retrieve the first pageSize results.
		int pageSize = 10;
		List<Object> searchResults = new ArrayList<Object>(pageSize);
		IndependentObjectSet resultsObjectSet = searchScope.fetchObjects(searchSQL, pageSize, filter, true);
		PageIterator pageIterator = resultsObjectSet.pageIterator();
		if (pageIterator.nextPage()) {
			for (Object obj : pageIterator.getCurrentPage()) {
				searchResults.add(obj);
			}
		}
			
				
		// Retrieve the privilege masks for the search results.
		HashMap<Object, Long> privMasks = callbacks.getP8PrivilegeMasks(repositoryId, searchResults);
		System.out.println("searchResults.size :: "+searchResults.size());
		int count = 0;
		
		for (Object searchResult : searchResults) {
			Document doc = (Document) searchResult;
			count++;
			/*
			 *  IDs use the form:
			 *  <object class name>,<object store ID>,<object ID>
			 */
			StringBuffer sbId = new StringBuffer();
			sbId.append(doc.getClassName()).append(",").append(objectStore.get_Id().toString()).append(",").append(doc.get_Id().toString());

			long privileges = (privMasks != null) ? privMasks.get(doc) : 0L;

			JSONResultSetRow row = new JSONResultSetRow(sbId.toString(), doc.get_Name(), doc.get_MimeType(), privileges);

			// Add locked user information (if any)
			row.addAttribute("locked", doc.isLocked(), JSONResultSetRow.TYPE_BOOLEAN, null, (new Boolean(doc.isLocked())).toString());
			row.addAttribute("lockedUser", doc.get_LockOwner(), JSONResultSetRow.TYPE_STRING, null, doc.get_LockOwner());
			row.addAttribute("currentVersion", doc.get_IsCurrentVersion(), JSONResultSetRow.TYPE_BOOLEAN, null, (new Boolean(doc.get_IsCurrentVersion())).toString());

			// Add the attributes
			row.addAttribute("ID", doc.get_Id().toString(), JSONResultSetRow.TYPE_STRING, null, doc.get_Id().toString());
			addAnnotationRow(doc,row);
			row.addAttribute("ROWNUMBER", count, JSONResultSetRow.TYPE_STRING, null, count+"");
			row.addAttribute("className", doc.getClassName(), JSONResultSetRow.TYPE_STRING, null, doc.getClassName());
			addPropertiesToRow(resultSet_columns,props,row,doc,objectStore);
			row.addAttribute("ModifiedBy", doc.get_LastModifier(), JSONResultSetRow.TYPE_STRING, null, doc.get_LastModifier());
			row.addAttribute("LastModified", doc.get_DateLastModified().toString(), JSONResultSetRow.TYPE_TIMESTAMP, null, doc.get_DateLastModified().toString());
			row.addAttribute("Version", doc.get_MajorVersionNumber() + "." + doc.get_MinorVersionNumber(), JSONResultSetRow.TYPE_STRING, null, doc.get_MajorVersionNumber() + "." + doc.get_MinorVersionNumber());

			if (doc.getProperties().isPropertyPresent(PropertyNames.CM_THUMBNAILS)) {
				CmThumbnailSet thumbnails = doc.get_CmThumbnails();
				if (thumbnails != null && !thumbnails.isEmpty()) {
					Iterator iter = thumbnails.iterator();
					while (iter.hasNext()) {
						CmThumbnail thumbnailObj = (CmThumbnail) iter.next();
						byte[] thumbnail = thumbnailObj.get_Image();

						if (thumbnail != null && thumbnail.length > 0) {
							JSONObject thumbnailJson = new JSONObject();
							thumbnailJson.put("mimeType", thumbnailObj.get_MimeType());
							thumbnailJson.put("image", "data:" + thumbnailObj.get_MimeType() + ";base64," + Base64.encodeBase64String(thumbnail));
							row.addAttribute("thumbnail", thumbnailJson, JSONResultSetRow.TYPE_OBJECT, null, "");
						}
					}
				}
				thumbnails = null;
			}
			
			jsonResultSet.addRow(row);
		}
	}

	private static void addAnnotationRow(Document doc, JSONResultSetRow row) {
		AnnotationSet annotationSet = doc.get_Annotations();
		if(annotationSet!=null && !annotationSet.isEmpty())
			row.addAttribute("Annotation", doc.get_Id().toString(), JSONResultSetRow.TYPE_STRING, null, doc.get_Id().toString());
		else
			row.addAttribute("Annotation", "null", JSONResultSetRow.TYPE_STRING, null, "null");
	}

	private static void addPropertiesToRow(String resultSet_columns, java.util.Properties props, JSONResultSetRow row, Document doc, ObjectStore objectStore) {
		System.out.println("&&&&&&&&&&&&&&&&&%%%%%addPropertiesToRow() %%%%%%%%%%%%%%%%%%%%%%");
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		StringTokenizer tokenizer = new StringTokenizer(resultSet_columns,",");
		Map<String, String> propMap = new HashMap<String, String>();
		ClassDefinition classDefinition = Factory.ClassDefinition.fetchInstance(objectStore, "FEP_CLAIMS", null);
		PropertyDefinitionList propertiesDef = classDefinition.get_PropertyDefinitions();
		Iterator iter= propertiesDef.iterator();
		while(iter.hasNext()){
			PropertyDefinition propDef = (PropertyDefinition)iter.next();
			propMap.put(propDef.get_SymbolicName(), propDef.get_DataType().toString());
		}
		while (tokenizer.hasMoreElements()) {
			String prop = (String) tokenizer.nextElement();
			String value = "";
			if(prop.equalsIgnoreCase("ID")){
				value = doc.get_Id().toString();
			}else{
				if( propMap != null && propMap.containsKey(prop))
				{
					String typeID = propMap.get(prop);
					if(typeID == "DATE"){
						value = doc.getProperties().getDateTimeValue(prop)!=null?sdf.format(doc.getProperties().getDateTimeValue(prop)).toString():"";
					}
					if(typeID == "STRING"){
						value = doc.getProperties().getStringValue(prop)!=null?doc.getProperties().getStringValue(prop).toString():"";
					}
					if(typeID == "BOOLEAN"){
						value = doc.getProperties().getBooleanValue(prop)!=null?doc.getProperties().getBooleanValue(prop).toString():"";
					}
					if(typeID == "INTEGER"){
						value = doc.getProperties().getInteger32Value(prop)!=null?doc.getProperties().getInteger32Value(prop).toString():"";
					}
				}
			}
			row.addAttribute(prop, value,JSONResultSetRow.TYPE_STRING, null,value);
		}
	}

	/**
	 * Builds the details and magazine structure for P8. This method will use a set of predefined columns and fields
	 * that always exist on every P8 object.
	 * 
	 * @param jsonResultSet
	 *            The JSONResultSetResponse object to populate with the structure
	 * @param messageResources
	 *            The resource bundle to retrieve default column names
	 * @param clientLocale
	 *            The locale of the client
	 * @param props 
	 * @param listOfProps 
	 */
	private static void buildP8ResultStructure(JSONResultSetResponse jsonResultSet, MessageResources resources,
			Locale clientLocale, String resultSet_columns, java.util.Properties props) {
		String[] states = new String[1];
		states[0] = JSONResultSetColumn.STATE_LOCKED;

		jsonResultSet.addColumn(new JSONResultSetColumn("&nbsp;", "multiStateIcon", false, states));
		jsonResultSet.addColumn(new JSONResultSetColumn("&nbsp;", "17px", "mimeTypeIcon", null, false));
		JSONResultSetColumn column = new JSONResultSetColumn("&nbsp;", "25px", "Annotation", null, false);
		column.put("decorator", "fepUtilityPluginAnnotationDecorator");
		jsonResultSet.addColumn(column);
		//jsonResultSet.addColumn(new JSONResultSetColumn(resources.getMessage(clientLocale, "search.results.header.id"), "200px", "ID", null, false));
		jsonResultSet.addColumn(new JSONResultSetColumn("#Row", "30px", "ROWNUMBER", null, false));
		jsonResultSet.addColumn(new JSONResultSetColumn("Class Name", "125px", "className", null, false));
		addPropertiesToColumn(jsonResultSet,resultSet_columns,props);
		jsonResultSet.addColumn(new JSONResultSetColumn(resources.getMessage(clientLocale, "search.results.header.lastModifiedByUser"), "125px", "ModifiedBy", null, false));
		jsonResultSet.addColumn(new JSONResultSetColumn(resources.getMessage(clientLocale, "search.results.header.lastModifiedTimestamp"), "175px", "LastModified", null, false));
		jsonResultSet.addColumn(new JSONResultSetColumn(resources.getMessage(clientLocale, "search.results.header.version"), "50px", "Version", null, false));

		// Magazine view
		jsonResultSet.addMagazineColumn(new JSONResultSetColumn("thumbnail", "60px", "thumbnail", null, null));

		JSONArray fieldsToDisplay = new JSONArray();
		
		
		JSONObject jsonObj = new JSONObject();
		/*jsonObj.put("field", "Annotation");
		jsonObj.put("displayName", "#Anno");
		fieldsToDisplay.add(jsonObj);*/
		
		jsonObj = new JSONObject();
		jsonObj.put("field", "ROWNUMBER");
		jsonObj.put("displayName", "#Row");
		fieldsToDisplay.add(jsonObj);
		
		jsonObj = new JSONObject();
		jsonObj.put("field", "className");
		jsonObj.put("displayName", "Class");
		fieldsToDisplay.add(jsonObj);

		addPropertiesAsFieldsToDisplay(resultSet_columns,props,fieldsToDisplay);
		

		jsonObj = new JSONObject();
		jsonObj.put("field", "ModifiedBy");
		jsonObj.put("displayName", resources.getMessage(clientLocale, "search.results.header.lastModifiedByUser"));
		fieldsToDisplay.add(jsonObj);

		jsonObj = new JSONObject();
		jsonObj.put("field", "LastModified");
		jsonObj.put("displayName", resources.getMessage(clientLocale, "search.results.header.lastModifiedTimestamp"));
		fieldsToDisplay.add(jsonObj);

		jsonObj = new JSONObject();
		jsonObj.put("field", "Version");
		jsonObj.put("displayName", resources.getMessage(clientLocale, "search.results.header.lastModifiedTimestamp"));
		fieldsToDisplay.add(jsonObj);
		
		JSONArray extraFieldsToDisplay = new JSONArray();
		jsonObj = new JSONObject();
		jsonObj.put("field", "CmThumbnails");
		jsonObj.put("displayName", "Thumbnails");
		jsonObj.put("decorator", "MagazineViewDecorator.contentCellDecoratorCmThumbnails");
		extraFieldsToDisplay.add(jsonObj);

		jsonResultSet.addMagazineColumn(new JSONResultSetColumn("content", "100%", "content", fieldsToDisplay, extraFieldsToDisplay));
	}

	private static void addPropertiesAsFieldsToDisplay(String resultSet_columns, java.util.Properties props, JSONArray fieldsToDisplay) {
		StringTokenizer tokenizer = new StringTokenizer(resultSet_columns,",");
		while (tokenizer.hasMoreElements()) {
			String prop = (String) tokenizer.nextElement();
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("field", prop);
			jsonObj.put("displayName", props.getProperty(prop+"_display_name"));
			fieldsToDisplay.add(jsonObj);
		}
	}

	private static void addPropertiesToColumn(JSONResultSetResponse jsonResultSet, String listOfProps, java.util.Properties props) {
		StringTokenizer tokenizer = new StringTokenizer(listOfProps,",");
		while (tokenizer.hasMoreElements()) {
			String prop = (String) tokenizer.nextElement();
			jsonResultSet.addColumn(new JSONResultSetColumn(props.getProperty(prop+"_display_name"), "200px", prop, null, false));
		}
		
	}
}