package com.fep.custom.constants;

public class PluginConstants {
	

	public static final String Date_Criteria = "Date_Criteria";
	public static final String STATE = "STATE";
	public static final String SRCID = "SRCID";
	public static final String RTNCD = "RTNCD";
	public static final String DOCUMENT_CLASS = "DOCUMENT_CLASS";
	public static final String STATUS = "STATUS";
	public static final String DOCTYPE = "DOCTYPE";
	
	
	public static final String document_Classes_ParentClass = "document_Classes_ParentClass";
	public static final String resultSet_columns = "resultSet_columns";
	
	public static final String json_Files_to_be_included = "json_Files_to_be_included";
	public static final String user_interface_search_fields = "user_interface_search_fields";
	public static final String PROPERTIES_FILE_PATH = "C:\\IBM\\ECMClient\\properties\\fep_properties\\FEPPlugin_Properties.properties";
}
