package com.navigator.filenet.americas.cshare.net.response;

import javax.servlet.http.HttpServletRequest;
import com.ibm.ecm.extension.PluginResponseFilter;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import com.ibm.ecm.json.JSONResultSetColumn;
import com.ibm.ecm.json.JSONResultSetResponse;
import com.ibm.json.java.JSONObject;


public class DocumentTiltleResponseFilter extends PluginResponseFilter {

	
	public String[] getFilteredServices() {
		return new String[] { "/p8/search",  "/p8/openFolder" };
	}

	public void filter(String serverType, PluginServiceCallbacks callbacks,
			HttpServletRequest request, JSONObject jsonResponse) throws Exception {
		String desktopId = request.getParameter("desktop");
		if (desktopId != null && desktopId.equals("Test")) {
			JSONResultSetResponse jsonResultSetResponse = (JSONResultSetResponse) jsonResponse;
			for (int i = 0; i < jsonResultSetResponse.getColumnCount(); i++) {
				JSONResultSetColumn column = jsonResultSetResponse.getColumn(i);
				String columnName = (String) column.get("field");
				if (columnName != null && (columnName.trim().equals("{NAME}"))) { 
					column.put("Name", "Document Title");
					column.setName("Document Title");
				}
			}
		}
	}
}

